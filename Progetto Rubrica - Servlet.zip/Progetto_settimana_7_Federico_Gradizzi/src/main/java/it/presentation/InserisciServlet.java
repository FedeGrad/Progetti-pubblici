package it.presentation;

import java.io.IOException;
import java.io.PrintWriter;

import it.business.RubricaEJB;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InserisciServlet
 */
public class InserisciServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	RubricaEJB rejb;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InserisciServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String numero1 = request.getParameter("numero1");
		String numero2 = request.getParameter("numero2");

		rejb.inserisciContatto(nome, cognome, email, numero1, numero2);
		out.println("Contatto registrato");
	}

}
