package it.presentation;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import it.business.RubricaEJB;
import it.data.Contatto;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StampaValoriServlet
 */
public class StampaValoriServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	RubricaEJB rejb;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StampaValoriServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Contatto> cont = rejb.visualizzaAllContatti();
		PrintWriter out = response.getWriter();
		out.println("Lista contatti in rubrica<br>");
		for (Contatto c : cont) {
			out.println(c + "<br>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

}
