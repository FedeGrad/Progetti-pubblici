package it.data;

import java.util.ArrayList;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Contatto")
@NamedQuery(name = "cerca.all.contatti", query = "SELECT c FROM Contatto c")
@NamedQuery(name = "cerca.contatto.cognome", query = "SELECT c FROM Contatto c WHERE c.cognome LIKE :cognome")
@NamedQuery(name = "cerca.contatto.numero", query = "SELECT c FROM Contatto c JOIN NumTelefono n ON n.contatto.id = c.id WHERE n.numero =:numero")
public class Contatto {

	private int id;
	private String nome;
	private String cognome;
	private String email;
	private ArrayList<NumTelefono> numTelefoni = new ArrayList<>();

	public Contatto() {
	}

	public Contatto(int id) {
		this.id = id;
	}

	public Contatto(String nome, String cognome, String email, NumTelefono numero1) {
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.numTelefoni.add(numero1);
	}

	public Contatto(int id, String nome, String cognome, String email, NumTelefono numero1) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.email = email;
		this.numTelefoni.add(numero1);
	}

	public void inserisciAltriNumeri(NumTelefono numeroN) {
		this.numTelefoni.add(numeroN);
	}

	@Override
	public String toString() {
		return "Contatto id " + id + ", nome " + nome + ", cognome " + cognome + ", email " + email + ", num Telefono"
				+ numTelefoni;
	}

	@Id
	@Column(name = "id_contatto")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "nome_contatto")
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Column(name = "cognome_contatto")
	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	@Column(name = "email_contatto")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@OneToMany(mappedBy = "contatto", cascade = CascadeType.ALL, orphanRemoval = true)
	public ArrayList<NumTelefono> getNumTelefoni() {
		return numTelefoni;
	}

	public void setNumTelefoni(ArrayList<NumTelefono> numTelefoni) {
		this.numTelefoni = numTelefoni;
	}
	
}
