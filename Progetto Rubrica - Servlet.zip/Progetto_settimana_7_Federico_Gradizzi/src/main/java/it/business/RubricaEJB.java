package it.business;


import java.util.List;
import it.data.Contatto;
import it.data.NumTelefono;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Stateless
@LocalBean
public class RubricaEJB {

	@PersistenceContext(unitName = "rubricaPS")
	EntityManager em;

	public RubricaEJB() {
	}
	
	public List<Contatto> visualizzaAllContatti() {
		Query q = em.createNamedQuery("cerca.all.contatti");
		return q.getResultList();
	}
	
    public Contatto trovaContattoNumero(String numero) {
    	Query q = em.createNamedQuery("cerca.contatto.numero");
    	q.setParameter("numero", numero);
    	return (Contatto) q.getSingleResult();
    }
	
	public Contatto trovaContattoCognome(String cognome) {
		Query q = em.createNamedQuery("cerca.contatto.cognome");
    	q.setParameter("cognome", "%" + cognome + "%");
		return (Contatto) q.getSingleResult();
	}

	public void inserisciContatto(String nome, String cognome, String email, String numero1, String numero2) {
		
		NumTelefono n1 = new NumTelefono(numero1);
		Contatto c = new Contatto();
		if(numero2.equals("")) {
			c = new Contatto(nome, cognome, email, n1);
			n1.setContatto(c);
		} else {
		c = new Contatto(nome, cognome, email, n1);
		NumTelefono n2 = new NumTelefono(numero2);
		c.inserisciAltriNumeri(n2);
		n1.setContatto(c);
		n2.setContatto(c);
		}
		inserisciContatto(c);
	}
	
	public void inserisciContatto(Contatto c) {
		em.persist(c);
	}
	
	public void eliminaContattoId(String idT) {
		int id = Integer.parseInt(idT);
		Contatto c = new Contatto(id);
		eliminaContattoId(c);
	}
	
	public void eliminaContattoId(Contatto c) {
		em.remove(em.merge(c));
	}
	
    public void modificaContatto(String idT, String nome, String cognome, String email, String numero1, String numero2) {
    	int id = Integer.parseInt(idT);
    	NumTelefono n1 = new NumTelefono(numero1);
    	Contatto c = new Contatto();
		if(numero2.equals("")) {
			c = new Contatto(id, nome, cognome, email, n1);
			n1.setContatto(c);
		} else {
		c = new Contatto(id, nome, cognome, email, n1);
		NumTelefono n2 = new NumTelefono(numero2);
		n1.setContatto(c);
		n2.setContatto(c);
		c.inserisciAltriNumeri(n2);
		}
    	modificaContatto(c);
    }
    
    public void modificaContatto(Contatto c) {
    	em.merge(c);
    }
}
