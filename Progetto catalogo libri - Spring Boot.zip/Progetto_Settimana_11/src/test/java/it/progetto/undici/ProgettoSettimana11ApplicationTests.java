package it.progetto.undici;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoSettimana11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
