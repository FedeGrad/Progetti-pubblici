package it.business;

import it.data.ContocorrenteDAO;

public class Main {

	public static void main(String[] args) {

//		Contocorrente cont = ContocorrenteDAO.getContoCorrente(12);
//		System.out.println(cont);
//		ContocorrenteDAO.versa(123, 2000);
//		ContocorrenteDAO.ritira(123, 2200);
//		ContocorrenteDAO.esiste(123);
//		System.out.println(ContocorrenteDAO.verificaPassword(123, 555));
		
		
	}

}
