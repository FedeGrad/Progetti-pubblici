package it.business;

import it.data.Contocorrente;
import it.data.ContocorrenteDAO;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;

/**
 * Session Bean implementation class BancomatEJB
 */
@Stateless
@LocalBean
public class BancomatEJB {

    /**
     * Default constructor. 
     */
    public BancomatEJB() {
    }
    
    public Contocorrente getContocorrente(int numero) {
    	return ContocorrenteDAO.getContoCorrente(numero);
    }
    
    public boolean versa(int numero, float quantita) {
    	return ContocorrenteDAO.versa(numero, quantita);
    }
    
    public boolean preleva(int numero, float quantita) {
    	return ContocorrenteDAO.ritira(numero, quantita);
    }
    
    public boolean esiste(int numero) {
    	return ContocorrenteDAO.esiste(numero);
    }
    
    public boolean verificaSaldo(int numero, float quantita) {
    	return ContocorrenteDAO.verificaConto(numero, quantita);
    }
    
    public boolean verificaPassword(int numero, int password) {
    	return ContocorrenteDAO.verificaPassword(numero, password);
    }
    
    public boolean inserisciPassword(int numero, int password) {
    	return ContocorrenteDAO.inserisciPassword(numero, password);
    }
    
	public boolean controllaOperazione(String operazione, int numero, float quantita, int password) {
		if (operazione.equals("versamento") && esiste(numero) == true && quantita > 0 && 
				verificaPassword(numero, password) == true ) {
			return true;
		} else if(operazione.equals("preleva") == true && esiste(numero) == true &&  quantita > 0 &&
				verificaPassword(numero, password) == true) {
			return true;
		} else if(operazione.equals("saldo") && esiste(numero) == true && 
				verificaPassword(numero, password) == true) {
			return true;
		}
	return false;
}

}
