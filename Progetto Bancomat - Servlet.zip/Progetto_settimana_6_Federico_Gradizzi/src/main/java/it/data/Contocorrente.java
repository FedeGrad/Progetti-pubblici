package it.data;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name = "contocorrente")
@NamedQuery(name = "stampa.dati", query = "SELECT c FROM Contocorrente c WHERE c.numero = numero")
@NamedQuery(name = "veramento", query = "UPDATE Contocorrente c SET c.saldo = c.saldo +:importo WHERE c.numero =:numero")
@NamedQuery(name = "prelievo", query = "UPDATE Contocorrente c SET c.saldo = c.saldo -:importo WHERE c.numero =:numero")
public class Contocorrente {

	private int numero;
	private String intestatario;
	private float saldo;

	public Contocorrente() {
	}

	public Contocorrente(int numero, String intestatario, float saldo) {
		super();
		this.numero = numero;
		this.intestatario = intestatario;
		this.saldo = saldo;
	}

	@Override
	public String toString() {
		return "Intestatario del conto corrente numero " + numero + ": " + intestatario + "<br>saldo attuale: " + saldo;
	}

	@Id
	@Column(name = "numero")
	public int getNumero() {
		return numero;
	}

	@Column(name = "intestatario")
	public String getIntestatario() {
		return intestatario;
	}

	@Column(name = "saldo")
	public float getSaldo() {
		return saldo;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public void setIntestatario(String intestatario) {
		this.intestatario = intestatario;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}

}
