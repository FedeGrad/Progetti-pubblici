package it.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ContocorrenteDAO {

	protected static final Logger logger = LoggerFactory.getLogger(ContocorrenteDAO.class);

	public static Contocorrente getContoCorrente(int numero) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		Contocorrente contocorrenteTrovato = new Contocorrente();
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT * FROM contocorrente WHERE numero = ? ";
			ps = con.prepareStatement(query);
			ps.setInt(1, numero);
			rs = ps.executeQuery();
			if (rs.next()) {
				contocorrenteTrovato.setNumero(rs.getInt(1));
				contocorrenteTrovato.setIntestatario(rs.getString(2));
				contocorrenteTrovato.setSaldo(rs.getFloat(3));
			}
			logger.info("metodo getContocorrente - query eseguita");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("metodo getContocorrente - errore SQL");
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
				logger.error("metodo getContocorrente - errore generico");
			}
		}
		return contocorrenteTrovato;
	}

	public static boolean versa(int numero, float quantita) {
		int numUpdate = 0;
		boolean riuscito = false;
		PreparedStatement ps = null;
		try {
			if (quantita > 0) {
				Connection con = ConnectionFactory.getConnection();
				String query = "UPDATE contocorrente SET saldo = saldo+? WHERE numero = ?";
				ps = con.prepareStatement(query);
				ps.setFloat(1, quantita);
				ps.setInt(2, numero);
				numUpdate = ps.executeUpdate();
				System.out.println(numUpdate);
			}
			logger.info("metodo versa - query eseguita");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("metodo versa - errore SQL");
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
				logger.error("metodo versa - errore generico");
			}
		}
		if (numUpdate > 0) {
			logger.info("metodo versa - versamento riuscito");
			return riuscito = true;
		} else {
			logger.error("metodo versa - versamento fallito");
			return riuscito;
		}
	}

	public static boolean verificaConto(int numero, float quantita) {
		Statement st = null;
		boolean check = false;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT saldo FROM contocorrente WHERE numero = " + numero;
			st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			if (rs.next()) {
				float trovato = rs.getFloat(1);
				if (trovato < quantita) {
					check = false;
					logger.info("verificaConto - quantita negativa");
				} else
					check = true;
				logger.info("verificaConto - verificato");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("verificaConto - errore SQL");
		}
		return check;
	}

	public static boolean ritira(int numero, float quantita) {
		int numUpdate = 0;
		boolean riuscito = false;
		PreparedStatement ps = null;
		try {
			if (verificaConto(numero, quantita)) {
				Connection con = ConnectionFactory.getConnection();
				String query = "UPDATE contocorrente SET saldo = saldo-? WHERE numero = ? ";
				ps = con.prepareStatement(query);
				ps.setFloat(1, quantita);
				ps.setInt(2, numero);
				numUpdate = ps.executeUpdate();
				System.out.println(numUpdate);
				// }
			}
			logger.info("metodo ritira - query eseguita");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("metodo ritira - errore SQL");
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
				logger.error("metodo ritira - errore generico");
			}
		}
		if (numUpdate > 0) {
			logger.info("metodo ritira - ritiro avvenuto");
			return riuscito = true;
		} else {
			logger.info("metodo ritira - ritiro fallito");
			return riuscito;
		}
	}

	public static boolean esiste(int numero) {
		Statement st = null;
		boolean check = false;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT numero FROM contocorrente WHERE numero = " + numero;
			st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			if (rs.next()) {
				check = true;
				logger.info("metodo esiste - valore presente");
			} else
				logger.info("metodo esiste - valore assente");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("metodo esiste - errore SQL");
		}
		return check;
	}

	public static boolean verificaPassword(int numero, int password) {
		Statement st = null;
		boolean check = false;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT password FROM contocorrente WHERE numero = " + numero;
			st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			if (rs.next()) {
				int trovato = rs.getInt(1);
				if (trovato == password) {
					logger.info("verificaPSW - psw trovata");
					check = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("errore SQL");
		}
		logger.info("verificaPsw - psw non trovata");
		return check;
	}

	public static boolean inserisciPassword(int numero, int password) {
		int numUpdate = 0;
		PreparedStatement ps = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "UPDATE contocorrente SET password = ? WHERE numero = ?";
			ps = con.prepareStatement(query);
			ps.setInt(1, password);
			ps.setInt(2, numero);
			numUpdate = ps.executeUpdate();
			logger.info("inserisciPsw - query eseguita");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("inserisciPsw - errore SQL");
		} finally {
			try {
				ps.close();
			} catch (Exception e) {
				logger.error("inserisciPsw - errore generico");
			}
		}
		if (numUpdate > 0) {
			logger.info("inserisciPsw - psw inserita");
			return true;
		} else {
			logger.info("inserisciPsw - psw non inserita");
			return false;
		}
	}

}
