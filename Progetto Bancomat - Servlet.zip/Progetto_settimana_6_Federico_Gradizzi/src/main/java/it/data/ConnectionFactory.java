package it.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConnectionFactory {

	protected static final Logger logger = LoggerFactory.getLogger(ConnectionFactory.class);

	public static final String URL = "jdbc:postgresql://localhost:5432/bancadb";
	public static final String USER = "postgres";
	public static final String PASSWORD = "postgress";

	public static Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(URL, USER, PASSWORD);
			logger.info("connesso");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("connessione fallita");
		}
		return con;
	}

}
