package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import it.business.BancomatEJB;

/**
 * Servlet implementation class GestionePassword
 */
public class GestionePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	BancomatEJB bejb;

	public GestionePassword() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		int numero = Integer.parseInt(request.getParameter("numero_conto"));
		int imp_password = Integer.parseInt(request.getParameter("imposta_psw"));

		if (bejb.inserisciPassword(numero, imp_password) == true) {
			// out.println("Password modificata correttamente");
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/psw_inserita.jsp").forward(request,
					response);
		} else {
			// out.println("Errore");
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/conto_inesistente.jsp").forward(request,
					response);
		}
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
