package it.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import it.business.BancomatEJB;
import it.data.Contocorrente;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@EJB
	BancomatEJB bejb;

	public MyServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int numero = Integer.parseInt(request.getParameter("numero_conto"));
		float quantita = 0;
		if (request.getParameter("quantita_euro") == "") {
			quantita = 0;
		} else {
			quantita = Float.valueOf(request.getParameter("quantita_euro"));
		}
		int passwordInserimento = Integer.parseInt(request.getParameter("password"));
		String operazione = request.getParameter("scelta");

		if (bejb.controllaOperazione(operazione, numero, quantita, passwordInserimento)) {
			switch (operazione) {
				case "saldo":
					// out.println(bejb.getContocorrente(numero));
					Contocorrente conto = new Contocorrente();
					conto = bejb.getContocorrente(numero);
					Integer numConto = conto.getNumero();
					Float saldo = conto.getSaldo();
					String intestatario = conto.getIntestatario();
					request.setAttribute("numero", numConto);
					request.setAttribute("saldo", saldo);
					request.setAttribute("intestatario", intestatario);
					request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/mostra_saldo.jsp").forward(request,
							response);
					break;

				case "preleva":
					bejb.preleva(numero, quantita);
					// out.println("Prelievo eseguito correttamente<br>");
					// out.println("saldo attuale: " + bejb.getContocorrente(numero).getSaldo());
					float saldoPrelievo = bejb.getContocorrente(numero).getSaldo();
					request.setAttribute("saldo_prelievo", saldoPrelievo);
					request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/mostra_prelievo.jsp")
							.forward(request, response);
					break;

				case "versamento":
					bejb.versa(numero, quantita);
					// out.println("Versamento eseguito correttamente<br>");
					// out.println("saldo attuale: " + bejb.getContocorrente(numero).getSaldo());
					float saldoVersamento = bejb.getContocorrente(numero).getSaldo();
					request.setAttribute("saldo_versamento", saldoVersamento);
					request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/mostra_versamento.jsp")
							.forward(request, response);
					break;
			}

		} else if (bejb.controllaOperazione(operazione, numero, quantita, passwordInserimento) == false
				&& bejb.esiste(numero) == false) {
			// out.println("Il conto non esiste");
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/conto_inesistente.jsp").forward(request,
					response);
		} else if (bejb.controllaOperazione(operazione, numero, quantita, passwordInserimento) == false
				&& bejb.verificaPassword(numero, passwordInserimento) == false) {
			// out.println("Hai sbagliato la password");
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/psw_errata.jsp").forward(request, response);
		} else if (bejb.controllaOperazione(operazione, numero, quantita, passwordInserimento) == false
				&& quantita <= 0) {
			// out.println("non puoi versare una quantit� negativa");
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/versamento_negativo.jsp").forward(request,
					response);
		} else if (bejb.controllaOperazione(operazione, numero, quantita, passwordInserimento) == false
				&& bejb.verificaSaldo(numero, quantita) == false) {
			// out.println("Limite prelievo superato<br>" + "saldo attuale: "
			// + bejb.getContocorrente(numero).getSaldo() + "<br>prova a ritirare una somma
			// inferiore");
			float saldoLimite = bejb.getContocorrente(numero).getSaldo();
			request.setAttribute("saldo_limite", saldoLimite);
			request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/limite_prelievo.jsp").forward(request,
					response);
		}
	}

	// protected void doPost(HttpServletRequest request, HttpServletResponse
	// response) throws ServletException, IOException {
	//
	// doGet(request, response);
	// }

}
