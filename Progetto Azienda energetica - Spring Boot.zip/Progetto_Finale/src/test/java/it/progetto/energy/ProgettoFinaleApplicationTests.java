package it.progetto.energy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoFinaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
