package it.progetto.energy.model;

public enum StatoFattura {

	PAGATA, 
	NON_PAGATA, 
	ANNULLATA, 
	SCADUTA, 
	DA_RIMBORSARE, 
	RIMBORSATA;

	private StatoFattura() {
	}

}
