package it.progetto.energy.exception;

public class WrongInsertException extends Exception {

	public WrongInsertException(String message) {
		super(message);
	}

	
}
