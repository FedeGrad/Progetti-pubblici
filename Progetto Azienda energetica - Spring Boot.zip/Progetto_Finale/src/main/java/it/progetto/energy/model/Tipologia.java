package it.progetto.energy.model;

public enum Tipologia {
	PA,
	SAS,
	SPA,
	SRL;
	
	private Tipologia() {
	}

}
