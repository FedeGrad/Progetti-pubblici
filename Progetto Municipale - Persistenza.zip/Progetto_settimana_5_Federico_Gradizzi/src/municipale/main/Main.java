package municipale.main;

import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import municipale.auto.Auto;
import municipale.auto.AutoDAO;
import municipale.infrazione.Infrazione;
import municipale.infrazione.InfrazioneDAO;

public class Main {

	protected static final Logger logger = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		int risposta = 0;
		String domanda = null;
		do {
			System.out.println("Selezionare l'opzione desiderata inserendo il numero corrispondente");
			System.out.println("1 - Inserisci dati auto \n2 - inserisci dati infrazione \n"
					+ "3 - Visualizza tutte le auto \n4 - Cerca auto da targa \n"
					+ "5 - Visualizza tutte le infrazioni commesse \n6 - Elimina infrazione");
			risposta = input.nextInt();
			input.nextLine();

			switch (risposta) {
				case 1: // metodo che inserisce i dati auto nel DB tabella auto (insert)
					System.out.println("Sezione inserimento autoveicolo");
					System.out.println("inserisci la Marca");
					String marca = input.nextLine();
					System.out.println("inserisci il Modello");
					String modello = input.nextLine();
					System.out.println("inserisci la targa");
					String targa;
					Auto auto = new Auto(Auto.controlloTarga(targa = input.nextLine()), marca, modello);
					AutoDAO.inserisciAuto(auto);
					break;

				case 2: // metodo che inserisce un'infrazione nel DB tabella infrazione (insert)
					System.out.println("Sezione inserimento infrazione");
					// System.out.println("inserisci l'id");
					// int id = input.nextInt();
					// input.nextLine();
					System.out.println("inserisci la data");
					String data = input.nextLine();
					System.out.println("inserisci la tipologia d'infrazione");
					String tipo = input.nextLine();
					System.out.println("inserisci l'importo");
					int importo = input.nextInt();
					input.nextLine();
					System.out.println("inserisci la targa dell'auto");
					String targaIn;
					Infrazione in = new Infrazione(data, tipo, importo,
							Auto.controlloTarga(targaIn = input.nextLine()));
					InfrazioneDAO.inserisciInfrazione(in);
					break;

				case 3: // metodo per visualizzate le auto nel DB (select) tab auto
					System.out.println("le auto schedate sono:");
					for (Auto autoDB : AutoDAO.getAllAuto()) {
						System.out.println(autoDB);
					}
					break;

				case 4: // metodo visualizza auto per targa(select - PK) tab auto
					System.out.println("inserisci la targa dell'auto che desideri ricercare");
					String targa1 = input.nextLine();
					System.out.println(AutoDAO.cercaAuto(targa1));
					break;

				case 5: // metodo vivualizza dati auto e infrazioni da targa (select - join) tab auto -
						// infraz.
					System.out.println("Ecco tuttei i veicoli con infrazioni registrate");
					// InfrazioneDAO.stampaDatiInfrazioniAuto();
					InfrazioneDAO.viewStampaDatiInfrazioniAuto();
					break;

				case 6: // metodo cancella infrazione da targa (delete) tab infrazioni
					System.out.println("inserisci l'ID dell'infrazione da eliminare");
					int idA = input.nextInt();
					input.nextLine();
					InfrazioneDAO.eliminaInfrazione(idA);
					break;

				default:
					System.out.println("comando errato");
					break;
			}

			System.out.println("Vuoi continuare?");
			domanda = input.nextLine();

		} while (domanda.equalsIgnoreCase("si"));
		System.out.println("Buona giornata agente");
		logger.debug("programma terminato");
	}

}
