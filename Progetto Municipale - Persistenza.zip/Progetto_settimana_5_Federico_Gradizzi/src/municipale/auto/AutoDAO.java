package municipale.auto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import municipale.ConnectionFactory;

public class AutoDAO {

	protected static final Logger logger = LoggerFactory.getLogger(AutoDAO.class);

	public static boolean inserisciAuto(Auto auto) {
		int numUpdate = 0;
		boolean riuscito = false;
		PreparedStatement ps = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "INSERT INTO auto(targa, marca, modello) VALUES (?, ?, ?);";

			ps = con.prepareStatement(query);
			ps.setString(1, auto.getTarga());
			ps.setString(2, auto.getMarca());
			ps.setString(3, auto.getModello());
			numUpdate = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
		if (numUpdate > 0) {
			System.out.println("inserimento avvenuto");
			logger.info("query eseguita");
			return riuscito = true;
		} else {
			System.out.println("inserimento fallito");
			logger.info("errore inserimento");
			return riuscito;
		}
	}

	public static ArrayList<Auto> getAllAuto() {
		PreparedStatement ps = null;
		ArrayList<Auto> automobili = new ArrayList<>();
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT * FROM auto";
			ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				automobili.add(new Auto(rs.getString(1), rs.getString(2), rs.getString(3)));
			}
			logger.info("query eseguita");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
		return automobili;
	}

	public static Auto cercaAuto(String targa) {
		PreparedStatement ps = null;
		Auto autotrovata = new Auto();
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT * FROM auto WHERE targa = ? ";
			ps = con.prepareStatement(query);
			ps.setString(1, Auto.controlloTarga(targa));
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				autotrovata.setTarga(rs.getString(1));
				autotrovata.setMarca(rs.getString(2));
				autotrovata.setModello(rs.getString(3));
			}
			logger.info("query eseguita");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
		return autotrovata;
	}

}
