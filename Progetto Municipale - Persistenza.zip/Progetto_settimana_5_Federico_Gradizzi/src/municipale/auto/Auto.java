package municipale.auto;

import java.util.Scanner;

public class Auto {
	static Scanner input = new Scanner(System.in);

	private String targa;
	private String marca;
	private String modello;

	public Auto() {
	}

	public Auto(String targa, String marca, String modello) {
		this.targa = targa;
		this.marca = marca;
		this.modello = modello;
	}

	public static String controlloTarga(String targa) {
		while (!targa.matches("[a-zA-Z]{2}[0-9]{3,4}[a-zA-Z]{2}")) {
			System.out.println("Inserisci un valore valido");
			targa = input.nextLine();
		}
		return targa;
	}

	@Override
	public String toString() {
		if (this.targa == null) {
			return "non trovata";
		} else
			return "Auto targata " + targa + ", marca: " + marca + ", modello: " + modello;
	}

	public String getTarga() {
		return targa;
	}

	public String getMarca() {
		return marca;
	}

	public String getModello() {
		return modello;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public void setTarga(String targa) {
		while (!targa.matches("[a-zA-Z]{2}[0-9]{3,4}[a-zA-Z]{2}")) {
			System.out.println("Inserisci un valore valido");
			targa = input.nextLine();
		}
		this.targa = targa;
	}

}
