package municipale.infrazione;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import municipale.ConnectionFactory;

public class InfrazioneDAO {

	protected static final Logger logger = LoggerFactory.getLogger(InfrazioneDAO.class);

	public static boolean inserisciInfrazione(Infrazione infrazione) {
		int numUpdate = 0;
		boolean riuscito = false;
		PreparedStatement ps = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "INSERT INTO infrazione(data, tipo, importo, targa_auto) " + "VALUES (?, ?, ?, ?);";
			ps = con.prepareStatement(query);
//			ps.setInt(1, infrazione.getId());
			ps.setString(1, infrazione.getData());
			ps.setString(2, infrazione.getTipo());
			ps.setDouble(3, infrazione.getImporto());
			ps.setString(4, infrazione.getTarga());
			numUpdate = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
		if (numUpdate > 0) {
			System.out.println("infrazione caricata correttamente");
			logger.info("query eseguita");
			return riuscito = true;
		} else {
			System.out.println("inserimento fallito");
			logger.error("errore inserimento");
			return riuscito;
		}
	}

	public static void stampaDatiInfrazioniAuto() {
		PreparedStatement ps = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT auto.targa, auto.marca, auto.modello,"
					+ "infrazione.tipo, infrazione.data, infrazione.importo FROM auto "
					+ "JOIN infrazione ON auto.targa = infrazione.Targa_auto";
			ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println("Auto targata: " + rs.getString(1) + " - Marca - " + rs.getString(2)
						+ " - Modello - " + rs.getString(3) + "\nInfrazione riscontrata: " + rs.getString(4)
						+ "\nin data: " + rs.getString(5) + "\nimporto da versare: " + rs.getInt(6) + " euro");
				System.out.println("---------------------------------------");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
	}
	
	public static void viewStampaDatiInfrazioniAuto() {
		PreparedStatement ps = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "SELECT * FROM autoInfrazioni";
			ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println("Auto targata: " + rs.getString(1) + " - Marca - " + rs.getString(2)
						+ " - Modello - " + rs.getString(3) + "\nInfrazione riscontrata: " + rs.getString(4)
						+ "\nin data: " + rs.getString(5) + "\nimporto da versare: " + rs.getInt(6) + " euro");
				System.out.println("---------------------------------------");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
	}

	public static boolean eliminaInfrazione(int id) {
		PreparedStatement ps = null;
		try {
			Connection con = ConnectionFactory.getConnection();
			String query = "DELETE FROM infrazione WHERE '" + id + "' = id;";
			ps = con.prepareStatement(query);
			ps.executeUpdate();
			System.out.println("Infrazione eliminata correttamente");
			logger.info("query eseguita");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("errore");
			return false;
		} finally {
			try {
				ps.close();
			} catch (SQLException e) {
			}
		}
	}

}
