package municipale.infrazione;

import java.util.Scanner;

public class Infrazione {
	Scanner input = new Scanner(System.in);

	private int id;
	private String data;
	private String tipo;
	private double importo;
	private String targa;

	public Infrazione() {
	}

	public Infrazione(String data, String tipo, int importo, String targa) {
		this.data = data;
		this.tipo = tipo;
		this.importo = importo;
		this.targa = targa;
	}

	public Infrazione(int id, String data, String tipo, int importo, String targa) {
		this.id = id;
		this.data = data;
		this.tipo = tipo;
		this.importo = importo;
		this.targa = targa;
	}

	public int getId() {
		return id;
	}

	public String getData() {
		return data;
	}

	public String getTipo() {
		return tipo;
	}

	public double getImporto() {
		return importo;
	}

	public String getTarga() {
		return targa;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setImporto(double importo) {
		this.importo = importo;
	}

	public void setTarga(String targa) {
		while (!targa.matches("[a-zA-Z]{2}[0-9]{3,4}[a-zA-Z]{2}")) {
			System.out.println("Inserisci un valore valido");
			targa = input.nextLine();
		}
		this.targa = targa;
	}

}
