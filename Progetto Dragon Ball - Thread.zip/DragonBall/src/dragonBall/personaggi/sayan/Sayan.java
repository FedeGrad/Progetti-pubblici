package dragonBall.personaggi.sayan;

import dragonBall.personaggi.Personaggio;

public class Sayan extends Personaggio {
	
	{
		super.setRazza("Sayan");
	}

	public Sayan() {
	}

	public Sayan(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}


	
	

}
