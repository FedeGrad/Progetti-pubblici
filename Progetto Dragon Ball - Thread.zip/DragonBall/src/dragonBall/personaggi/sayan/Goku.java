package dragonBall.personaggi.sayan;

import dragonBall.attacchi.Mossa;

public class Goku extends Sayan {
	
	{
		super.setNome("Goku");
		super.setPuntiVita(95);
		super.setForza(10);
		super.setSchivata(0.7);
		super.setDifesa(0.5);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Onda Energetica!", 27, 0.4));
		super.setMosse(new Mossa("Kaioh Ken", 18, 0.7));
		super.setMosse(new Mossa("Afferra l'avversario", 10, 1));
		super.setMosse(new Mossa("Sfera Genki Dama!", 100, 0.1));
	}
	
	
	public Goku() {
		super();
	}

	public Goku(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}


}
