package dragonBall.personaggi.sayan;

import dragonBall.attacchi.Mossa;

public class Vegeta extends Sayan {

	{
		super.setNome("Vegeta");
		super.setPuntiVita(90);
		super.setForza(9);
		super.setSchivata(0.6);
		super.setDifesa(0.5);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Final flash", 15, 0.6));
		super.setMosse(new Mossa("Proiettile infinito", 20, 0.5));
		super.setMosse(new Mossa("Big Bang Attak!", 25, 0.4));
		super.setMosse(new Mossa("Supernova", 80, 0.1));
	}
	
	
	public Vegeta() {
		super();
	}

	public Vegeta(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}


	
}
