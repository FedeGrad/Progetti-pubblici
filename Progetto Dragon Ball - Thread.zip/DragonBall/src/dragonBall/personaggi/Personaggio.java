package dragonBall.personaggi;

import java.util.ArrayList;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dragonBall.attacchi.Attacco;
import dragonBall.attacchi.Mossa;

public abstract class Personaggio implements Attacco {

	protected static final Logger log = LoggerFactory.getLogger(Personaggio.class);

	private String nome;
	private String razza;
	private double puntiVita;
	private int forza;
	private double schivata;
	private double difesa;
	private ArrayList<Mossa> mosse = new ArrayList<>();

	public Personaggio() {
	}

	public Personaggio(double puntiVita, int forza, double schivata, double difesa) {
		this();
		this.puntiVita = puntiVita;
		this.forza = forza;
		this.schivata = schivata;
		this.difesa = difesa;
	}

	public String toString() {
		String s = "";
		s = "Combattente: " + nome + ", razza: " + razza + "\nMosse a disposizione: ";
		for (Mossa mossa : this.mosse) {
			s += "," + mossa;
		}
		return s;
	}

	@Override
	public synchronized void attacca(Personaggio pSub) {
		
		Random random = new Random();
		double successo = random.nextDouble();
		int estratto = random.nextInt(this.getAttacchi().size());
//		log.info(""+estratto);
		Mossa mossa = this.getAttacchi().get(estratto);
//		log.info(mossa.toString());
		// logica per la schiavata
		if (mossa.getPrecisione() * pSub.getSchivata() <= successo) {
			// danno a segno
			System.out.println(getNome() + " sferra " + mossa.getNome() + " su " + pSub.getNome());
			pSub.setPuntiVita(pSub.getPuntiVita() - pSub.getDifesa() * mossa.getDanno());
			if (pSub.getPuntiVita() >= 0) {
				System.out.println(pSub.getNome() + " rimane con " + pSub.getPuntiVita() + " punti vita");
			} else {
				pSub.setPuntiVita(0);
				System.out.println(pSub.getNome() + " ha perso i sensi ");
			}
			return;
		} else
			System.out.println(pSub.getNome() + " schiva l'attacco");
		return;
	}

	// getter
	public String getNome() {
		return nome;
	}

	public String getRazza() {
		return razza;
	}

	public double getPuntiVita() {
		return puntiVita;
	}

	public int getForza() {
		return forza;
	}

	public double getSchivata() {
		return schivata;
	}

	public double getDifesa() {
		return difesa;
	}

	public ArrayList<Mossa> getAttacchi() {
		return mosse;
	}

	// setter
	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setRazza(String razza) {
		this.razza = razza;
	}

	public void setPuntiVita(double puntiVita) {
		this.puntiVita = puntiVita;
	}

	public void setForza(int forza) {
		this.forza = forza;
	}

	public void setSchivata(double schivata) {
		this.schivata = schivata;
	}

	public void setDifesa(double difesa) {
		this.difesa = difesa;
	}

	public void setMosse(Mossa mossa) {
		this.mosse.add(mossa);
	}

}
