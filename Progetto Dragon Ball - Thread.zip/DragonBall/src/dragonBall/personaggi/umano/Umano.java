package dragonBall.personaggi.umano;


import dragonBall.personaggi.Personaggio;

public class Umano extends Personaggio {
	
	{
		super.setRazza("Umano");
	}

	public Umano() {
	}

	public Umano(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}
	

}
