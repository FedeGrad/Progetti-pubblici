package dragonBall.personaggi.umano;

import dragonBall.attacchi.Mossa;

public class GenioDelleTartarughe extends Umano {
	
	{
		super.setNome("Genio delle tartarughe");
		super.setPuntiVita(50);
		super.setForza(7);
		super.setSchivata(0.3);
		super.setDifesa(0.3);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Onda Energetica", 19, 0.4));
		super.setMosse(new Mossa("Bomba di luce", 10, 0.7));
		super.setMosse(new Mossa("Raggio Letale", 20, 0.4));
		super.setMosse(new Mossa("Distruzione", 50, 0.2));
	}
	
	
	public GenioDelleTartarughe() {
		super();
	}

	public GenioDelleTartarughe(int puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}


}
