package dragonBall.personaggi.umano;

import dragonBall.attacchi.*;

public class Crilin extends Umano {
	
	{
		super.setNome("Crilin");
		super.setPuntiVita(55);
		super.setForza(5);
		super.setSchivata(0.4);
		super.setDifesa(0.3);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Onda Energetica", 15, 0.4));
		super.setMosse(new Mossa("Lama Circolare", 55, 0.1));
		super.setMosse(new Mossa("Proiettile Infinito", 25, 0.2));
		super.setMosse(new Mossa("Afferra l'avversario", 7, 1));
	}
	
	
	public Crilin() {
		super();
	}

	public Crilin(int puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}
	

}
