package dragonBall.personaggi.cyborg;

import dragonBall.attacchi.Mossa;

public class C17 extends Cyborg {
	
	{
		super.setNome("C-17");
		super.setPuntiVita(70);
		super.setForza(7);
		super.setSchivata(0.3);
		super.setDifesa(0.7);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Lama Circolare", 15, 0.6));
		super.setMosse(new Mossa("Proiettile Infinito", 25, 0.4));
		super.setMosse(new Mossa("Raggio Letale", 28, 0.3));
		super.setMosse(new Mossa("Distruzione", 100, 0.1));
	}
	
	
	public C17() {
		super();
	}

	public C17(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}

}
