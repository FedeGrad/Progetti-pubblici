package dragonBall.personaggi.cyborg;

import dragonBall.attacchi.Mossa;

public class C18 extends Cyborg {
	
	{
		super.setNome("C-18");
		super.setPuntiVita(70);
		super.setForza(6);
		super.setSchivata(0.4);
		super.setDifesa(0.6);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Lama Circolare", 17, 0.6));
		super.setMosse(new Mossa("Proiettile infinito", 24, 0.4));
		super.setMosse(new Mossa("Raggio Letale", 30, 0.3));
		super.setMosse(new Mossa("Distruttore", 100, 0.1));
	}
	
	
	public C18() {
		super();
	}

	public C18(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}


}
