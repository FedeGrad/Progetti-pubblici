package dragonBall.personaggi.cyborg;

import dragonBall.personaggi.Personaggio;

public class Cyborg extends Personaggio {
	
	{
		super.setRazza("Cyborg");
	}

	public Cyborg() {
	}

	public Cyborg(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}
	

}
