package dragonBall.personaggi.alieno;


import dragonBall.personaggi.Personaggio;

public abstract class Alieno extends Personaggio {
	
	{
		super.setRazza("Alieno");
	}

	public Alieno() {
	}

	public Alieno(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}

	
	

}
