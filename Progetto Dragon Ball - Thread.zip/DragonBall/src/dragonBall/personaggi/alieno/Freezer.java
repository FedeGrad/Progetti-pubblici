package dragonBall.personaggi.alieno;

import dragonBall.attacchi.Mossa;

public class Freezer extends Alieno {

	{
		super.setNome("Freezer");
		super.setPuntiVita(95);
		super.setForza(8);
		super.setSchivata(0.4);
		super.setDifesa(0.7);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Lama Circolare", 19, 0.6));
		super.setMosse(new Mossa("Cannone Dell'anima", 22, 0.5));
		super.setMosse(new Mossa("Colpo Nova", 45, 0.2));
		super.setMosse(new Mossa("Supernova", 100, 0.1));
	}

	public Freezer() {
		super();
	}

	public Freezer(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}

}
