package dragonBall.personaggi.demone;

import dragonBall.attacchi.Mossa;

public class PerfectCell extends Demone {
	
	{
		super.setNome("Perfect Cell");
		super.setPuntiVita(100);
		super.setForza(8);
		super.setSchivata(0.7);
		super.setDifesa(0.4);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Proiettile infinito", 15, 0.8));
		super.setMosse(new Mossa("Raggio letale", 25, 0.4));
		super.setMosse(new Mossa("Bomba di luce", 20, 0.5));
		super.setMosse(new Mossa("Distruzione", 100, 0.1));
	}
	
	
	public PerfectCell() {
		super();
	}

	public PerfectCell(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}



}
