package dragonBall.personaggi.demone;

import dragonBall.attacchi.Mossa;

public class Darbula extends Demone {
	
	{
		super.setNome("Darbula");
		super.setPuntiVita(75);
		super.setForza(6);
		super.setSchivata(0.5);
		super.setDifesa(0.5);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Lama circolare", 20, 0.6));
		super.setMosse(new Mossa("Proiettile infinito", 25, 0.4));
		super.setMosse(new Mossa("Afferra il personaggio", 10, 1));
		super.setMosse(new Mossa("Lampo Demoniaco", 80, 0.1));
	}
	
	
	public Darbula() {
		super();
	}

	public Darbula(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}



}
