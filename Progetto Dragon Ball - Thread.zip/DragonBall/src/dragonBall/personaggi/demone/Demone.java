package dragonBall.personaggi.demone;

import dragonBall.personaggi.Personaggio;

public class Demone extends Personaggio {
	
	{
		super.setRazza("Demone");
	}

	public Demone() {
	}

	public Demone(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}



}
