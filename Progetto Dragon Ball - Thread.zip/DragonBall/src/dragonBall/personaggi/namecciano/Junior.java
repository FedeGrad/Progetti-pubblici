package dragonBall.personaggi.namecciano;

import dragonBall.attacchi.Mossa;

public class Junior extends Namecciano {
	
	{
		super.setNome("Junior");
		super.setPuntiVita(75);
		super.setForza(6);
		super.setSchivata(0.5);
		super.setDifesa(0.3);
		super.setMosse(new Mossa("Attacco Base", getForza(), 0.5));
		super.setMosse(new Mossa("Raggio Letale", 30, 0.2));
		super.setMosse(new Mossa("Bomba di luce", 18, 0.6));
		super.setMosse(new Mossa("Afferra l'avversario", 9, 1));
		super.setMosse(new Mossa("Cannone dell'anima", 70, 0.1));
	}
	
	
	public Junior() {
		super();
	}

	public Junior(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}



}
