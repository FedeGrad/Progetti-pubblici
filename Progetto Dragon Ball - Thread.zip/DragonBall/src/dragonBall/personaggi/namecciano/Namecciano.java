package dragonBall.personaggi.namecciano;

import dragonBall.personaggi.Personaggio;

public class Namecciano extends Personaggio {
	
	{
		super.setRazza("Namecciano");
	}

	public Namecciano() {
	}

	public Namecciano(double puntiVita, int forza, double schivata, double difesa) {
		super(puntiVita, forza, schivata, difesa);
	}

	

}
