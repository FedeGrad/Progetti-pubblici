package dragonBall.main;

import java.io.File;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dragonBall.combattimento.Combattimento;
import dragonBall.personaggi.*;
import dragonBall.personaggi.alieno.Freezer;
import dragonBall.personaggi.cyborg.C17;
import dragonBall.personaggi.cyborg.C18;
import dragonBall.personaggi.demone.Darbula;
import dragonBall.personaggi.demone.PerfectCell;
import dragonBall.personaggi.namecciano.Junior;
import dragonBall.personaggi.sayan.Goku;
import dragonBall.personaggi.sayan.Vegeta;
import dragonBall.personaggi.umano.Crilin;
import dragonBall.personaggi.umano.GenioDelleTartarughe;

public class Main {
	
	protected static final Logger logger = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) {
		ArrayList<Personaggio> personaggi = new ArrayList<>();
		GenioDelleTartarughe genio = new GenioDelleTartarughe();
		Crilin crilin = new Crilin();
		Goku goku = new Goku();
		Vegeta vegeta = new Vegeta();
		Junior junior = new Junior();
		Darbula darbula = new Darbula();
		PerfectCell cell = new PerfectCell();
		C17 c17 = new C17();
		C18 c18 = new C18();
		Freezer freezer = new Freezer();
		
		//aggiunta personaggi
		personaggi.add(genio);
		personaggi.add(crilin);
		personaggi.add(goku);
		personaggi.add(vegeta);
		personaggi.add(junior);
		personaggi.add(darbula);
		personaggi.add(cell);
		personaggi.add(c17);
		personaggi.add(c18);
		personaggi.add(freezer);

		Combattimento c1 = new Combattimento(genio, crilin);
		Combattimento c2 = new Combattimento(goku, vegeta);
		Combattimento c3 = new Combattimento(junior, darbula);
		Combattimento c4 = new Combattimento(cell, freezer);
		Combattimento c5 = new Combattimento(c17, c18);
		
		System.out.println("Si da il via al torneo delle 7 sfere");
		
		c1.start();
		try {
			c1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		c2.start();
		try {
			c2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		c3.start();
		try {
			c3.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		c4.start();
		try {
			c4.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		c5.start();
		try {
			c5.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		File file = new File("Vincitori");		
		Combattimento.stampaVincitori(file);
	}

}
