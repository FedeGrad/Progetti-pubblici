package dragonBall.combattimento;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.core.util.FileUtil;
import dragonBall.personaggi.Personaggio;

public class Combattimento extends Thread {

	protected static final Logger logger = LoggerFactory.getLogger(Combattimento.class);

	private static int idT = 0;
	private int id;
	private Personaggio personaggio1;
	private Personaggio personaggio2;
	private String messaggio;

	public Combattimento() {
		this.id = ++idT;
		this.messaggio = "Inizia il " + id + "� scontro";
	}

	public Combattimento(Personaggio personaggio1, Personaggio personaggio2) {
		this();
		this.personaggio1 = personaggio1;
		this.personaggio2 = personaggio2;
	}

	@Override
	public void run() {
		scontro();
		System.out.println("inizia tra poco un altro scontro");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public synchronized void scontro() {
		Personaggio vincitore = null;
		Random random = new Random();
		System.out.println(this.messaggio);
		int numero = random.nextInt(2);
		if (numero == 0) {
			while (getPersonaggio1().getPuntiVita() > 0 || getPersonaggio2().getPuntiVita() > 0) {
				getPersonaggio1().attacca(this.personaggio2);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (getPersonaggio2().getPuntiVita() <= 0) {
					vincitore = getPersonaggio1();
					break;
				}
				getPersonaggio2().attacca(this.personaggio1);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (getPersonaggio1().getPuntiVita() <= 0) {
					vincitore = getPersonaggio2();
					break;
				}
			}
		} else if (numero == 1) {
			while (getPersonaggio1().getPuntiVita() > 0 || getPersonaggio2().getPuntiVita() > 0) {
				getPersonaggio2().attacca(this.personaggio1);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (getPersonaggio1().getPuntiVita() <= 0) {
					vincitore = getPersonaggio2();
					break;
				}
				getPersonaggio1().attacca(this.personaggio2);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (getPersonaggio2().getPuntiVita() <= 0) {
					vincitore = getPersonaggio1();
					break;
				}
			}
		}
		System.out.println("il vincitore �: " + vincitore.getNome());
		salvaVincitore(vincitore);
	}

	private synchronized void salvaVincitore(Personaggio personaggio) {
		File file = new File("Vincitori");
		if (file.exists()) {
			try {
				String vincitore = "Il vincitore del " + id + "� scontro � " + personaggio.getNome() + "\n";
//				FileUtils.writeStringToFile(file, vincitore, "UTF8", true);
				FileUtils.writeStringToFile(file, vincitore, true);
			} catch (IOException e) {
				e.printStackTrace();
				logger.error("Errore di salvataggio");
				return;
			}
		} else if (!file.exists()) {
			logger.error("Il file non esiste");
			return;
		}
	}

	public static void stampaVincitori(File file) {
		if (file.exists()) {
			try {
				String vincitori = FileUtils.readFileToString(file);
				System.out.println(vincitori);
			} catch (IOException e) {
				e.printStackTrace();
				System.err.println("errore");
				return;
			}
		} else if (!file.exists()) {
			System.err.println("Il file non esiste");
			return;
		}
	}

	public Personaggio getPersonaggio1() {
		return personaggio1;
	}

	public Personaggio getPersonaggio2() {
		return personaggio2;
	}

	public void setPersonaggio1(Personaggio personaggio1) {
		this.personaggio1 = personaggio1;
	}

	public void setPersonaggio2(Personaggio personaggio2) {
		this.personaggio2 = personaggio2;
	}

}
