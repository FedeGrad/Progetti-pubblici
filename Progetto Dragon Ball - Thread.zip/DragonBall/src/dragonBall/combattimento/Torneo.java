package dragonBall.combattimento;

import java.util.ArrayList;

import dragonBall.personaggi.Personaggio;

/**
 * classe da implementare
 */
public class Torneo extends Thread {
	
	ArrayList<Personaggio> personaggi = new ArrayList<>();
	
	public Torneo() {
	}

	public Torneo(ArrayList<Personaggio> personaggi) {
		this.personaggi = personaggi;
	}

	@Override
	public void run() {
		
		
	}
	
	
	public void scontri() {
		
		
	}

	public ArrayList<Personaggio> getPersonaggi() {
		return personaggi;
	}

	public void setPersonaggi(ArrayList<Personaggio> personaggi) {
		this.personaggi = personaggi;
	}
	

}
