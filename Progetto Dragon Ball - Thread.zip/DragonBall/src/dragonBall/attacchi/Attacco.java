package dragonBall.attacchi;

import dragonBall.personaggi.Personaggio;

public interface Attacco {

 void attacca(Personaggio subisce);
 
}
