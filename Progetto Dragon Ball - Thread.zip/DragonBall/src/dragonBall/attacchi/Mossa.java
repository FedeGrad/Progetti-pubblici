package dragonBall.attacchi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Mossa {

	protected static final Logger logger = LoggerFactory.getLogger(Mossa.class);
	private String nome;
	private int danno;
	private double precisione;

	public Mossa() {
	}

	public Mossa(int danno, double precisione) {
		this.danno = danno;
		this.precisione = precisione;
	}

	public Mossa(String nome, int danno, double precisione) {
		this.nome = nome;
		this.danno = danno;
		this.precisione = precisione;
	}

	@Override
	public String toString() {
		return nome + ", danno: " + danno + ", precisione: " + precisione + "\n";
	}

	public String getNome() {
		return this.nome;
	}

	public int getDanno() {
		return this.danno;
	}

	public double getPrecisione() {
		return precisione;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setDanno(int danno) {
		this.danno = danno;
	}

	public void setPrecisione(double precisione) {
		this.precisione = precisione;
	}

}
